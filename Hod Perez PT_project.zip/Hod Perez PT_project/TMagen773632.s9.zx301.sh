#!/bin/bash
# student's name = Hod Perez
# code = s9
# class code = TMagen773632
# lecturer's name = Erel Regev


#create a list of ip in the subnet and create a directory for the script
function START()
{
	first_location=$(pwd)
	whoami=$(whoami)
	
	if [ "$whoami" != "root" ]; then
	echo -e "\nyou have to be root for continue... exiting"
	exit
	fi
	
	read -p "Enter an IP subnet (for example 192.168.17.0/24): " network

	if ! VALIDATE_SUBNET "$network"
	then
		echo -e '\033[1;31mValidation ip failed!\033[0m'
		echo -e '\033[1;31mexiting...\033[0m'
		exit
	fi
	
	y=0
	
	
	
	read -p "please insert a name for the output directory: " name_of_dir
	mkdir "$name_of_dir" > /dev/null 2>&1
	cd "$name_of_dir"
	list_ip_network=$(nmap $network -sn | grep "scan report" | awk '{print $NF}')
	
	CASE
}


#check the user input subnet is valid
function VALIDATE_SUBNET() {
    local subnet=$1

    IFS='/' read -r ip cidr <<< "$subnet"

    if [[ ! $ip =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        echo "Invalid IP format"
        return 1
    fi

    IFS='.' read -r octet1 octet2 octet3 octet4 <<< "$ip"
    for octet in $octet1 $octet2 $octet3 $octet4; do
        if ((octet < 0 || octet > 255)); then
            echo "Invalid IP address range"
            return 1
        fi
    done

    if [[ ! $cidr =~ ^[0-9]+$ ]] || ((cidr < 0 || cidr > 32)); then
        echo "Invalid subnet mask"
        return 1
    fi

    return 0
}


#ask the user for basic or full scanning
function CASE()
{
	echo -e "please insert a valid number for decide:\n1) Basic\n2) Full\n3) exit\n"
	read number
	case $number in
	1)
		BASIC
	;;
	
	2)
		FULL
	;;
	
	3)
		echo "exiting..."
		exit
	;;
	
	*)
		echo -e '\033[1;31myou entered wrong number\033[0m'
		echo
		CASE
	;;
	esac
	
}



List_Of_Packages_basic=( "nmap" "medusa" "masscan" )

#installing packages for basic scanning
function BASIC_TOOLS()
{
	for package in "${List_Of_Packages_basic[@]}"; do
		dpkg -s "$package" >/dev/null 2>&1 ||
		(echo -e "[*] starting to install the package $package.." &&
		sudo apt-get install "$package" -y >/dev/null 2>&1)
		echo "The package $package is installed on remote host."
	done
}


#commit scanning using nmap and masscan and save the result
function BASIC()
{
	echo
	BASIC_TOOLS
	echo
	
	for ip in $list_ip_network
	do
		{
			echo "started to scan $ip"
			timeout 30 nmap "$ip" -sV -F | grep open | awk '{for (i=4; i<=NF; i++) printf "%s ", $i; print ""}' > "$first_location/$name_of_dir/${ip}_nmap.txt" 2>&1
			timeout 30 masscan "$ip" -p U:1-100 > "$first_location/$name_of_dir/${ip}_masscan.txt" 2>&1
			timeout 30 nmap "$ip" -sV -sC --script=ftp-brute.nse -oN "$first_location/$name_of_dir/${ip}_brute.txt" > /dev/null 2>&1
			echo "Finished scanning $ip"
		} &
	done 
	wait
	
	echo -e "\e[1m\nAll scans completed!\e[0m"

	
	LOGIN_PASSWORDS
	LAST_FUNCTION
}


#asks the user fot the type of list he wants for use medusa on the target
function LOGIN_PASSWORDS()
{
	echo -e "\nplease choose one of the next options:\n1. create a file yourself using crunch tool and use it\n2. import your own file\n3. use the worst 12 passwords exist\n4. for exit\n"
	read num
	case $num in 
	1)
		echo
		if ! dpkg -s crunch >/dev/null 2>&1
		then
			echo "Installing crunch..."
			sudo apt-get install crunch -y >/dev/null 2>&1
			echo "Crunch installed on machine"
		fi
		
		CRUNCH
		echo
		
		for ip in $list_ip_network
		do
			{
				echo "started medusa $ip"
				timeout 30 medusa -h "$ip" -U crunch.txt -P crunch.txt -M ssh -t 10 -f > "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U crunch.txt -P crunch.txt -M rdp -t 10 -f > "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U crunch.txt -P crunch.txt -M ftp -t 10 -f > "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U crunch.txt -P crunch.txt -M telnet -t 10 -f > "${ip}_medusa.txt" 2>&1
				echo "Finished medusa $ip"
			} &
		done 
		wait
		echo
	;;
	
	2)
		echo
		CHECK_IF_FILE_EXIST
		echo 
		for ip in $list_ip_network
		do
			{
				echo -e "started medusa $ip"
				timeout 30 medusa -h "$ip" -U $imported_file -P $imported_file -M ssh -t 10 -f >> "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U $imported_file -P $imported_file -M rdp -t 10 -f >> "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U $imported_file -P $imported_file -M ftp -t 10 -f >> "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U $imported_file -P $imported_file -M telnet -t 10 -f >> "${ip}_medusa.txt" 2>&1
				echo -e "Finished medusa $ip"
			} &
		done 
		wait
		echo
	;;
	
	3)
		echo
		git clone https://github.com/hodperez/short-list-worst-passwords.git >/dev/null 2>&1
		
		for ip in $list_ip_network
		do
			{
				echo -e "started medusa $ip"
				timeout 30 medusa -h "$ip" -U "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -P "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -M ssh -t 10 -f >> "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -P "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -M rdp -t 10 -f >> "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -P "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -M ftp -t 10 -f >> "${ip}_medusa.txt" 2>&1
				timeout 30 medusa -h "$ip" -U "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -P "$first_location/$name_of_dir/short-list-worst-passwords/12_worst_passwords.txt" -M telnet -t 10 -f >> "${ip}_medusa.txt" 2>&1
				echo -e "Finished medusa $ip"
			} &
		done 
		wait
		echo
	;;
	
	4)
		exit
	;;
	
	*)
		echo
		echo -e '\033[1;31myou inserted wrong number\033[0m'
		LOGIN_PASSWORDS
	;;
	esac
		
	
	
}


#check if the full path the user gave is exist
function CHECK_IF_FILE_EXIST()
{
	read -p "Please enter full path to the memory file you want to investigate: " imported_file
	
	if ! [ -f "$imported_file" ]
	then
		((y++))
		if [ "$y" -eq 3 ]
		then
			echo -e "\nyou are giving me wrong paths, exiting..."
			exit
		fi
		echo -e "\nthis path is not exist"
		sleep 0.1
		CHECK_IF_FILE_EXIST
	fi
}


#creating a file contains strings using crunch, and check the user input is valid
function CRUNCH()
{	
	read -p "please insert minimum characters for the list of the password: " min
	read -p "please insert maximum characters for the list of the password: " max
	
	if ! [[ $min =~ ^[0-9]+$ ]] || ! [[ $max =~ ^[0-9]+$ ]]
	then 
		echo -e '\033[1;31myou need to insert a number\033[0m'
		echo
		CRUNCH
		return
    fi
    
    if [ $min -gt $max ]
    then
		echo -e '\033[1;31mminimum characters can not be bigger than maximum characters\033[0m'
		echo
		CRUNCH
		return
	fi
	
	read -p "please insert the chars you want the list will be contain of: " string
	echo
	crunch $min $max $string -o crunch.txt
	
}


#commit scanning using nmap and masscan and save the result
function FULL()
{
	echo
	FULL_TOOLS
	echo
	
	for ip in $list_ip_network
	do
		{
			echo "started to scan $ip"
			timeout 30 nmap "$ip" -sV -F | grep open | awk '{for (i=4; i<=NF; i++) printf "%s ", $i; print ""}' > "$first_location/$name_of_dir/${ip}_nmap.txt" 2>&1
			timeout 30 masscan "$ip" -p U:1-100 > "$first_location/$name_of_dir/${ip}_masscan.txt" 2>&1
			timeout 30 nmap "$ip" -sV -sC --script=ftp-brute.nse -oN "$first_location/$name_of_dir/${ip}_brute.txt" > /dev/null 2>&1
			timeout 30 nmap "$ip" -F -sV -sC --script=vulners.nse -oN "$first_location/$name_of_dir/${ip}_vuln.txt" > /dev/null 2>&1
			echo "Finished scanning $ip"
		} &
	done 
	wait
	
	echo -e "\e[1m\nAll scans completed!\e[0m"
	LOGIN_PASSWORDS
	SEARCHSPLOIT
	LAST_FUNCTION
	
}


#shows the vulnerability results for every ip only if exist results
function SEARCHSPLOIT()
{
	echo -e "\ndisplaying results of vulnerabilities for every ip\n"
	
	for ip in $list_ip_network
	do
		{		
			echo "the vulnerability results of $ip are:"
			echo
			cat "$first_location/$name_of_dir/${ip}_vuln.txt"
			echo
		}
	done
	
	CHECK
	
}


#if the user want to use searchsploit it shows him the services of every ip
function CHECK()
{
	read -p "do you want to use searchsploit? [yes/no]: " var
	
	if [[ "${var,,}" == "yes" ]]
	then
		for ip in $list_ip_network
		do
			{
				if grep -q '[^[:space:]]' "$first_location/$name_of_dir/${ip}_nmap.txt"
				then
					echo -e "\nthe version services of the ip $ip are:\n"
					cat "$first_location/$name_of_dir/${ip}_nmap.txt"
				fi
			}
		done
		FIND_EXPLOITS
	else
		if [[ "${var,,}" != "no" ]]
		then
			echo -e '\033[1;31myou inserted invalid option please try again\033[0m'
			CHECK
		fi
	fi
}


#search in searchsploit the exist exploits for the service the user insert, and let him option to search again
function FIND_EXPLOITS()
{
	echo
	read -p "please insert the service you want to find it exploits: " serv
	searchsploit "$serv"
	echo
	echo -e "please insert 'ag' if you want to search again for exploits for another service\nand insert anything else if you don't want: "
	read input
	if [[ "${input,,}" == "ag" ]]
	then
		FIND_EXPLOITS
	fi
}


List_Of_Packages_full=( "exploitdb" "nmap" "medusa" "masscan" )

#installing packages for the function FULL_TOOLS
function FULL_TOOLS()
{
	for package in "${List_Of_Packages_full[@]}"; do
		dpkg -s "$package" >/dev/null 2>&1 ||
		(echo -e "[*] starting to install the package $package.." &&
		sudo apt-get install "$package" -y >/dev/null 2>&1)
		echo "The package $package is installed on remote host."
	done
	
}


#print messages for the user and calling other functions
function LAST_FUNCTION()
{
	echo -e "\e[1mthe found information is in $name_of_dir directory\n\e[0m"
	SEARCH_KEYWORDS
	COMPRESS_TO_ZIP
	echo "the script arrived to the end"
}


#if the user choose for that, the script search inside the results by using keyword the user inserts
function SEARCH_KEYWORDS()
{
	read -p "do you want to serach inside the results? [yes/no]: " answer
	if [[ "${answer,,}" == "yes" ]]
	then
		read -p "please insert keyword/s for the thing you are looking for: " keywords
		echo
		if ! grep -iR "$keywords"; then
			echo "No matches found for '$keywords'."
		fi
		echo
	else
		if [[ "${answer,,}" != "no" ]]
		then
			echo -e '\033[1;31myou inserted invalid option please try again\033[0m'
			SEARCH_KEYWORDS
		fi
	fi
}


#compress all the file with the results if the user choose for that
function COMPRESS_TO_ZIP()
{
	read -p "do you want to compress all the results to zip file? [yes/no]: " variable_Y_N
	if [[ "${variable_Y_N,,}" == "yes" ]]
	then
		zip -r "$name_of_dir".zip "$first_location/$name_of_dir" 1> /dev/null
		echo -e "\e[1mthe zip file is in $first_location/$name_of_dir/$name_of_dir.zip\e[0m"
	else
		if [[ "${variable_Y_N,,}" != "no" ]]
		then
			echo -e '\033[1;31myou inserted invalid option please try again\033[0m'
			COMPRESS_TO_ZIP
		fi
	fi
	
}




START
